**Install the required Python packages**:

```bash
pip install -r requirements.txt
```

## 🚀 Usage

To use the tool, run the script from the command line as follows:

```bash
python NASdevX.py [options]
```

### Options

- **-u, --url**:
  Specify the target URL or IP address.

- **-f, --file**:
  Specify a file containing a list of URLs to scan.

- **-t, --threads**:
  Set the number of threads for concurrent scanning.

- **-o, --output**:
  Define an output file to save the scan results.

When a single URL is provided with the `-u` option and the target is vulnerable, the script will attempt to open an interactive shell.
