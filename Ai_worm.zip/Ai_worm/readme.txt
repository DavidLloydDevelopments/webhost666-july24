pip install paramiko requests



Telegram: @webhost666_official